# NOMBRE PROYECTO
MERCAELX

# DESCRIPCIÓN
Diseño a modo de ejemplo para el proyecto de MercaElx.

# ADVERTENCIAS
Se han desarrollado partes pública/privado por separado, siendo los '_private.html' los que indican ser privados.

Se han comentado: partes generadas por Django, elementos reutilizables, acciones o elementos únicamente visibles por usuarios registrados.

Se ha desarrollado dos códigos JS para poder incorportar tanto el NAV como el FOOTER, se usará plantilla.html a modo de ejemplo de como incorporar lo mencionado.

# Se ha organizado el proyecto en:
TEMPLATES (para almacenar: nav, footer...)
IMAGES (imágenes a mostrar)
CSS (ficheros css)
JS (el js para incorporar nav y footer)
ficheros html (los html no están en carpeta)
README.md